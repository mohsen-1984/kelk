Vazirmatn 33.003 and Sahel 3.4.0 — TrueType (.ttf) fonts for Windows and Word
=============================================================================

Kelk names these fonts in its Word files (.docx / .doc); Word shows them only when
they are installed on the reader's computer.

Install (Windows): select all the .ttf files → right-click → "Install" (or
"Install for all users"). macOS: double-click each file → "Install Font".
Then restart Word.

The fonts are the work of the late Saber Rastikerdar (https://rastikerdar.github.io/),
free under the SIL Open Font License 1.1 (OFL.txt in each folder).

----------------------------------------------------------------------------
فونت‌های وزیرمتن 33.003 و ساحل 3.4.0 — نسخهٔ TrueType (.ttf) برای ویندوز و Word

کِلک در فایل‌های Word نام این قلم‌ها را می‌نویسد و Word آن‌ها را فقط وقتی نشان می‌دهد
که روی رایانهٔ خواننده نصب باشند.

نصب در ویندوز: همهٔ فایل‌های .ttf را انتخاب کنید ← راست‌کلیک ← «Install» (یا
«Install for all users»). سپس Word را دوباره باز کنید.

این قلم‌ها کار زنده‌یاد صابر راستی‌کردار است (https://rastikerdar.github.io/) و با
مجوز آزاد SIL Open Font License 1.1 منتشر شده‌اند (فایل OFL.txt در هر پوشه).
