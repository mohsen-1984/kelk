Persian fonts for Windows and Word — TrueType (.ttf)
=====================================================

vazirmatn/       Vazirmatn 33.003   SIL Open Font License 1.1 (OFL.txt)
sahel/           Sahel 3.4.0        SIL Open Font License 1.1 (OFL.txt)
borna-rayaneh/   B Nazanin, B Nazanin Outline, B Mitra, B Titr 2.01
                 (c) Borna Rayaneh — no published license; see NOTICE.txt

Kelk names these fonts in its Word files (.docx / .doc); Word shows them only when
they are installed on the reader's computer.

Install (Windows): select all the .ttf files → right-click → "Install" (or
"Install for all users"). macOS: double-click each file → "Install Font".
Then restart Word.

Vazirmatn and Sahel are the work of the late Saber Rastikerdar
(https://rastikerdar.github.io/), free under the SIL Open Font License 1.1.

B Nazanin, B Mitra and B Titr belong to Borna Rayaneh (https://www.bornaray.com/).
They are downloadable from Borna Rayaneh's website; these files were obtained
unmodified from https://www.bornaray.com/Content/downloads/fonts/BNAZANIN.rar and
are included only for convenience. All rights belong to Borna Rayaneh
(borna-rayaneh/NOTICE.txt).

Files in borna-rayaneh/:
  BNAZANIN.TTF  B Nazanin            BNAZNNBD.TTF  B Nazanin Bold
  BNAZANNO.TTF  B Nazanin Outline    BMITRA.TTF    B Mitra
  BMITRABD.TTF  B Mitra Bold         BTITRBD.TTF   B Titr Bold

----------------------------------------------------------------------------
قلم‌های فارسی برای ویندوز و Word — نسخهٔ TrueType (.ttf)

vazirmatn/       وزیرمتن 33.003   مجوز آزاد SIL Open Font License 1.1
sahel/           ساحل 3.4.0       مجوز آزاد SIL Open Font License 1.1
borna-rayaneh/   بی‌نازنین، بی‌نازنین توخالی، بی‌میترا، بی‌تیتر 2.01 — متعلق به شرکت برنا رایانه

کِلک در فایل‌های Word نام این قلم‌ها را می‌نویسد و Word آن‌ها را فقط وقتی نشان می‌دهد
که روی رایانهٔ خواننده نصب باشند.

نصب در ویندوز: همهٔ فایل‌های .ttf را انتخاب کنید ← راست‌کلیک ← «Install» (یا
«Install for all users»). سپس Word را دوباره باز کنید.

وزیرمتن و ساحل کار زنده‌یاد صابر راستی‌کردار است (https://rastikerdar.github.io/) و با
مجوز آزاد SIL Open Font License 1.1 منتشر شده‌اند (فایل OFL.txt در هر پوشه).

بی‌نازنین، بی‌میترا و بی‌تیتر متعلق به شرکت برنا رایانه است و از وب‌سایت این شرکت
قابل دریافت‌اند. فایل‌ها بدون تغییر از همان‌جا برداشته شده‌اند و فقط برای راحتی
کاربران در این بسته آمده‌اند. همهٔ حقوق متعلق به شرکت برنا رایانه است (borna-rayaneh/NOTICE.txt).
